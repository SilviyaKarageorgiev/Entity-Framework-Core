﻿namespace P01_StudentSystem
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}