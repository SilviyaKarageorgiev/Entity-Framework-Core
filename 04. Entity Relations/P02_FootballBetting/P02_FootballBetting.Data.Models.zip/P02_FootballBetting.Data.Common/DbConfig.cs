﻿namespace P02_FootballBetting.Data.Common
{
    public static class DbConfig
    {
        public const string ConnectionString = @"Server=DESKTOP-UNCF2AK\SQLEXPRESS01;Database=Bet388;Integrated Security=True;Encrypt=False;";
    }
}