﻿namespace Artillery.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-UNCF2AK\SQLEXPRESS01;Database=Artillery;Integrated Security=True;Encrypt=False";
    }
}
