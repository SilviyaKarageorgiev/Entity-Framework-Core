﻿namespace Footballers.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-UNCF2AK\SQLEXPRESS01;Database=FootballersExam;Trusted_Connection=True";
    }
}
