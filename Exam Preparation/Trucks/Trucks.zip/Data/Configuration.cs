﻿namespace Trucks.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-UNCF2AK\SQLEXPRESS01;Database=Trucks;Trusted_Connection=True";
    }
}